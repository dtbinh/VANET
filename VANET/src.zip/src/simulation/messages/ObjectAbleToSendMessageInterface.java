package simulation.messages;

public interface ObjectAbleToSendMessageInterface {

	public void sendMessage(int receiver,String message);
}
