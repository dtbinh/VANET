package simulation.solutions.custom.DSR.Route;

/**
 * Empty route execption 
 * @author Jean-Paul Jamont
 */

/** exception raised when in a DSR route is empty */
public class EmptyRouteException extends Exception{

	public EmptyRouteException()
	{
		super();
	}
}
