package simulation.solutions.custom;

import java.util.Vector;

import simulation.entities.Agent;
import simulation.solutions.Solution;
import simulation.solutions.SolutionDescriber;
import simulation.solutions.SolutionDescriberException;
import simulation.solutions.SolutionException;
import simulation.solutions.custom.ClockUsersAndTranslators.UserAgent;
import simulation.solutions.custom.PreyPredator.PreyAgent;

/**
 * Horloge solution
 * @author Jean-Paul Jamont
 */
public class PreyPredatorSolution extends SolutionItem
{
	public PreyPredatorSolution()
	{
		super();

		
		try
		{
			Vector<Class> agents = new Vector<Class>();
			agents.add(Class.forName("simulation.solutions.custom.PreyPredator.PreyAgent"));
			agents.add(Class.forName("simulation.solutions.custom.PreyPredator.PredatorAgent"));
		
	
				super.setSolution(
						new Solution(
								new SolutionDescriber(
										"Jean-Paul Jamont" 					/* nom de l'auteurs de la solution */,
										"jean-paul.jamont@iut-valence.fr" 	/* adresse mail du correspondant*/,
										"Universite Pierre Mendes France" 	/* �tablissement de rattachement*/,
										"51 rue barthelemy de Laffemas, 26000 Valence" /* adresse */,
										"France" 							/* pays */,
										"PREY/PREDATOR - Prey/predator toy problem" 			/* D�nomination */,
										"1a" 								/* version */,
										"Implementation of a prey/predator toy problem" /*Description */
								), 
								agents										/* r�f�rence vers l'agent */
						)
				);
			
		} 
		catch(SolutionException e)
		{
			e.printStackTrace();
		}
		catch(SolutionDescriberException e)
		{
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
