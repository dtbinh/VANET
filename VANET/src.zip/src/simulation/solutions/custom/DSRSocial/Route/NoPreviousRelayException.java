package simulation.solutions.custom.DSRSocial.Route;

public class NoPreviousRelayException  extends Exception{

	public NoPreviousRelayException()
	{
		super();
	}
}
