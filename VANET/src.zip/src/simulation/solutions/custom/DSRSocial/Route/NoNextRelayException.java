package simulation.solutions.custom.DSRSocial.Route;

public class NoNextRelayException  extends Exception{
	public NoNextRelayException()
	{
		super();
	}

}
