package simulation.solutions.custom.DSRSocial.Route;

public class UnknownIdentifierException  extends Exception{

	public UnknownIdentifierException()
	{
		super();
	}
}
