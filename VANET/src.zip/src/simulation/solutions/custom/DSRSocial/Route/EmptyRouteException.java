package simulation.solutions.custom.DSRSocial.Route;

public class EmptyRouteException extends Exception{

	public EmptyRouteException()
	{
		super();
	}
}
