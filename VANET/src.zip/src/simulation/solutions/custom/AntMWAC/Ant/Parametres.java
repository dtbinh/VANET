package simulation.solutions.custom.AntMWAC.Ant;

public class Parametres {

	public static float taux_occupation =0;
	public static float alpha = 0.9f ; 
	public static float beta  =0.2f ;
	public static float teta = 8f; //nnnnn
	public static float delta_simple_membre =0.03f;
	public static float delta_representant  =0.01f;
	public static float  delta_liaison =0.02f;
	public static float gamma = 1 ;
	public static float Q  = 0.8f ;
	public static float roe = 0.3f;
	public static int Evaporation_Delay = 2000000;           
	public static int Energy_Update_Delay = 3000000;
	public static int Prevent_Delay =800000;
	public static int Taux_Delay = 2000000;
	public static int max_nbHoup= 150;
	
	
}
