package simulation.solutions.custom.PreyPredator.Messages;

import java.nio.ByteBuffer;

import simulation.messages.Frame;
import simulation.messages.Message;

/**
 * Specialize the fram for a DSR agent 
 * @author Jean-Paul Jamont
 */
public class PreyPredatorFrame extends Frame{

	/** to signal a broadcasted frame */
	final public static int BROADCAST = -1;

	/**
	 * 
	 * @param id
	 * @return
	 */
	public static String receiverIdToString(int id)
	{
		if (id==PreyPredatorFrame.BROADCAST)
			return "ALL_CLOSE_COMMUNICATING_OBJECT";
		else
			return ""+id;
	}

	/**
	 * parametrized constructor
	 * @param msg message flux 
	 */

	public static PreyPredatorFrame createFrame(byte[] msg)
	{

		System.out.println("IN CREATE FRAME "+PreyPredatorMessage.debugByteArray(msg));
		ByteBuffer buf=ByteBuffer.wrap(msg);
		int sender=buf.getInt();
		int receiver=buf.getInt();
		byte[] data = new byte[msg.length-8];
		//System.out.println("IN CREATE FRAME "+ClockUsersAndTranslatorsMessage.debugByteArray(msg)+" -> "+ClockUsersAndTranslatorsMessage.debugByteArray(data)+"  "+sender+"  "+receiver);
		for(int i=0;i<msg.length-8;i++) data[i]=buf.get();
		return new PreyPredatorFrame(sender,receiver,data);

	}
	/**
	 * 
	 * @param sender
	 * @param receiver
	 * @param msg
	 */
	public PreyPredatorFrame(int sender,int receiver,Message msg)
	{
		super(sender,receiver,msg);
		System.out.println("IN AHFRAME CONSTRUCTOR sender="+sender+" receiver="+receiver+" msg="+PreyPredatorMessage.debugByteArray(msg.toByteSequence()));

	}
	
	/**
	 * parametrized constructor
	 * @param sender  sender identifier
	 * @param receiver receiver identifier
	 * @param bytes the message seen as a byte array 
	 */
	public PreyPredatorFrame(int sender,int receiver,byte[] msg)
	{
		super(sender,receiver,PreyPredatorMessage.createMessage(msg));
	}

	public PreyPredatorMessage getClockUsersAndTranslatorsMessageInFrame()
	{
		return  PreyPredatorMessage.createMessage(super.getData());
	}

	/**
	 * returns a string representation of the frame
	 * @return the string representation
	 */
		public String toString()
	{	
		return "Frame de "+this.getSender()+" pour "+this.getReceiver()+". Le message est "+PreyPredatorMessage.createMessage(super.getData()).toString();
	}
}
