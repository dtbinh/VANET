package simulation.solutions.custom.PreyPredator;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.ListIterator;

import simulation.views.entity.imageInputBased.ImageFileBasedObjectView;
import simulation.entities.Agent;
import simulation.events.system.NotUnderstanbleRequestEvent;
import simulation.events.system.ReceivedMessageEvent;
import simulation.events.system.SendedMessageEvent;
import simulation.messages.Frame;
import simulation.messages.Message;
import simulation.messages.ObjectAbleToSendMessageInterface;
import simulation.multiagentSystem.MAS;
import simulation.multiagentSystem.SimulatedObject;
import simulation.solutions.custom.PreyPredator.Messages.PreyPredatorFrame;
import simulation.solutions.custom.PreyPredator.Messages.PreyPredatorMessage;
import simulation.utils.DoublePosition;
import simulation.utils.GeomVector;
import simulation.utils.IntegerPosition;
import simulation.utils.aDate;

/**
 * DSR agent
 * @author Jean-Paul Jamont
 */
public class PreyAgent extends Agent implements ObjectAbleToSendMessageInterface{

	//AgentHorlogeFrame frm;
	//AgentHorlogeMessage msg;

	public final static double DEFAULT_VISION_RADIUS = 140;
	public final static double DEFAULT_PROXIMITY_RADIUS=40;

	GeomVector vector_deplacement = new GeomVector();
	
	private boolean dead;

	private final static String PREY_SPRITE_FILENAME = "D:\\TestMASH\\Sprites\\PREY.PNG";

	
	private MotionManagement motionManagement;
	/**
	 * parameterized constructor
	 * @param mas reference to the multiagent system
	 * @param id identifier of the agent
	 * @param energy energy level of the agent
	 * @param range transmission range of the agent
	 */
	public PreyAgent(MAS mas, Integer id, Float energy,  Integer range) {
		super(mas, id, range);
		try {
			this.setNativeView(new ImageFileBasedObjectView(PreyAgent.PREY_SPRITE_FILENAME));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	/**
	 * Launched by the call of start method
	 */
	public void run()
	{

		System.out.println("D�marrage de l'entit� PreyAgent "+this.getUserId());
		this.motionManagement=new MotionManagement(this.getPosition());
		this.motionManagement.setSpeed(8);
		
		// wait a little amount of time to allow the construction of others agents 
		try{Thread.sleep(1000);}catch(Exception e){}

		this.setColor(Color.GREEN);



		// the decision loop is processed while the simulator don't requiere to kill or stop this agent)
		while(!isKilling() && !isStopping())
		{
			// Pause
			try{Thread.sleep(SLEEP_TIME_SLOT);}catch(Exception e){};

			// Preparation of the others threads
			while(  ((isSuspending()) && (!isKilling() && !isStopping()))) try{Thread.sleep(SLEEP_TIME_SLOT);}catch(Exception e){};

			LinkedList<SimulatedObject> neighboors = getPerceivedAgent(PreyAgent.DEFAULT_VISION_RADIUS);
			boolean finded=false;
			ListIterator<SimulatedObject> iter = neighboors.listIterator();
			
			LinkedList<vector_decision> decisionVectorList = new LinkedList<vector_decision>();
			while(iter.hasNext())
			{ 
				SimulatedObject item = iter.next();
				if(item.getObject().getUserId()!=1 && item.getObject().getUserId()!=this.getUserId())
				{
					decisionVectorList.add(new vector_decision(new GeomVector(this.getPosition().x-item.getPosition().x,this.getPosition().y-item.getPosition().y),1));
					
					if (this.getPosition().x<140) {decisionVectorList.add(new vector_decision(new GeomVector(this.getPosition().x-0,0),1));System.out.println("OUT");}
					if (this.getPosition().x>540) decisionVectorList.add(new vector_decision(new GeomVector(-1,0),1));
					if (this.getPosition().y<140) decisionVectorList.add(new vector_decision(new GeomVector(0,this.getPosition().y-0),1));
					if (this.getPosition().x>960) decisionVectorList.add(new vector_decision(new GeomVector(0,-1),1));
			
					finded=true;
				}
				
			//if(!finded) 	
			//	this.motionManagement.setDirection(new IntegerPosition(0,0));
			
		
			}
			tache_decision(decisionVectorList);
			this.motionManagement.move();
			String msg="BEEHHH de"+this.getUserId();
			sendMessage(PreyPredatorFrame.BROADCAST, msg);
			//receivedFrame(Frame frm);
			this.sleep(5000);

		}

	}

	public void tache_decision(LinkedList<vector_decision> v)
	{
		//init

		GeomVector vector_p1=new GeomVector(0,0);
		GeomVector vector_p2=new GeomVector(0,0);
		boolean danger = false;
		
		//test mort ?
		if (this.dead)
			this.motionManagement.setDirection(new IntegerPosition(0,0));
		else 
		{
			ListIterator<vector_decision> v_iter= v.listIterator();
			while(v_iter.hasNext())
			{
				vector_decision vector=v_iter.next();
				//cr�ation de deux vecteurs en fonction des priorit�es (forte ou faible)
				if (vector.getPriority()==1)
				{
					//pond�ration des vecteurs en fonction du nombre et de la distance 
					//vector.m
					vector.multi((float)(1/(vector.length()*vector.length())));
					vector_p1.add(vector.getVector());
					
					danger=true;
				}
				else 
				{
					vector.getVector().multi((float)(1/vector.length()));
					vector_p2.add(vector.getVector());
				}	
			}
			//test si besoin individuel fort
			if (danger)
			{
				vector_deplacement=vector_p1.getVector();

			}
			else 
			{
				vector_p2.add(vector_p1);
				vector_deplacement=vector_p1.getVector();
				
				if (vector_deplacement.equal(0, 0) )
				{
					
				}
			}
			
			this.motionManagement.setDirection(vector_deplacement);
		}
	}




	/**
	 * Launched by the call of start method
	 */
	public LinkedList<SimulatedObject> getPerceivedAgent(double visionRadius)
	{
		LinkedList<SimulatedObject> res = new LinkedList<SimulatedObject>();
		SimulatedObject[] tab=this.getMASObjectArray();
		for(int i=0;i<tab.length;i++)
			if(tab[i].getPosition().inCircleArea(this.getPosition(), visionRadius)) res.add(tab[i]);
		return res;
	}


	/**
	 * send a message
	 * @param receiver identifier of the receiver
	 * @param message message to send (a string)
	 */
	public void sendMessage(int receiver, String message)
	{
		System.out.println("ENVOIE D'UN MESSAGE PAR "+this.getUserId());
		this.sendFrame(new PreyPredatorFrame(this.getUserId(),receiver,new PreyPredatorMessage(this.getUserId(),receiver,message)));
	
	
	}


	/** allows to an object to receive a message
	 * @param frame the received frame 
	 */
	public synchronized void receivedFrame(Frame frame)
	{
		super.receivedFrame(frame);
		this.receivedFrame((PreyPredatorFrame) frame);
	}

	/** allows to an object to receive a message
	 * @param frame the received DSR_Frame 
	 */
	public void receivedFrame(PreyPredatorFrame frame)
	{
		if(frame.getReceiver()==this.getUserId() || frame.getReceiver()==Frame.BROADCAST)
		{
			// Message a traiter
			System.out.println("Hello"+frame);
		}
	}

	/**
	 * 
	 */
	public String toSpyWindows()
	{

		String res= "<HTML>";

		res+="Agent #"+this.getUserId()+"<BR>";
		res+="role = <I>PREY</I><BR>";
		
		res+="Position ( "+this.getPosition().x+" , "+this.getPosition().y+" ) <BR>";
		res+="vecteur_depalcemement( "+vector_deplacement.x+" , "+vector_deplacement.y+" )<BR>";

		return res+"</HTML>";
	}

	private class MotionManagement
	{
		private aDate lastMovmentIteration =null;
		private DoublePosition position;
		private double speed;	// speed in unit by second
		private GeomVector direction;


		public MotionManagement(IntegerPosition p)
		{
			this.position=new DoublePosition(p);
			this.speed=1.0f;
			this.lastMovmentIteration=new aDate();
			this.direction=new GeomVector();
		}

		/** take direction to the specified point */
		public void setDirection(IntegerPosition p)
		{
			this.setDirection(new GeomVector(p.x-this.position.x,p.y-this.position.y));
		}

		/**
		 * Set the direction according the vector parameters
		 * @param x 
		 * @param y
		 */
		public void setDirection(GeomVector v)
		{
			this.direction=v;
			v.normalize();
		}

		public void setSpeed(double speed)
		{
			this.speed=speed;
		}
		public void move()
		{
			long timeOfMovement=new aDate().differenceToMS(lastMovmentIteration);
			this.lastMovmentIteration=new aDate();

			if(this.direction.x!=0 || this.direction.y!=0)
			{
				//String cr="[#"+getUserId()+"] Position = "+this.position.toString()+"   Direction = "+this.direction.toString()+"  Time span = "+timeOfMovement+"    =>   ";
				this.position.x=this.position.x+this.direction.x*speed*timeOfMovement/1000.0;
				this.position.y=this.position.y+this.direction.y*speed*timeOfMovement/1000.0;
				//cr+=this.position.toString();
				//System.out.println(cr);
				setPosition(new IntegerPosition((int)this.position.x,(int)this.position.y));
			}
		}
	}
	
	private class vector_decision extends GeomVector
	{
		private int priority;
		
		public vector_decision(GeomVector v,int priority)
		{
			this.x=v.x;
			this.y=v.y;
			this.priority=priority;
		}
		
		public void setPriority(int p)
		{
			this.priority=p;
		}
		
		public int getPriority()
		{
			return this.priority;
		}
		
	}

}


