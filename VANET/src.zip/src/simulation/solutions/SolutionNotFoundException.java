package simulation.solutions;

/**
 * This exception is throwed when a requiered solution is not found
 * @author Jean-Paul Jamont
 */ 
public class SolutionNotFoundException extends Exception
{
}