package simulation.views.entity.basic;


public enum AgentViewEnumType {
	BMP,CROSS,SQUARE,RECTANGLE,CIRCLE,POINT;
}