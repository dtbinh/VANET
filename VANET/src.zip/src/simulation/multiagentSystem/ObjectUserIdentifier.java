package simulation.multiagentSystem;

public abstract class ObjectUserIdentifier {

	
}
